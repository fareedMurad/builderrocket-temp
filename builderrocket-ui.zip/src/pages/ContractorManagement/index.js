import ContractorManagement from './ContractorManagement';

export default ContractorManagement;