import ProjectTabs from './ProjectTabs';

export default ProjectTabs;