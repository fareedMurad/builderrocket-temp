import FileUpload from './FileUpload';

export default FileUpload;