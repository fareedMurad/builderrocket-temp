import AddProduct from './AddProduct';

export default AddProduct;