import ProductModal from './ProductModal';

export default ProductModal;