import CustomerModal from './CustomerModal';

export default CustomerModal;