import AddContractor from './AddContractor';

export default AddContractor;