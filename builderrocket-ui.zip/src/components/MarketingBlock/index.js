import MarketingBlock from './MarketingBlock';

export default MarketingBlock;
