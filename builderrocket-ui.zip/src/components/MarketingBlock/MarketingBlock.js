import React from 'react';
import './MarketingBlock.scss';

const MarketingBlock = () => {

    return (
        <div className='marketing-block'>
            <div className='marketing-block-body d-flex pt-5 justify-content-center'>
                <h1>Marketing</h1>
            </div>
        </div>
    );
}

export default MarketingBlock;