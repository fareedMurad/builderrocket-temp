import RoomAreaLayout from './RoomAreaLayout';

export default RoomAreaLayout;