import ClearChangesModal from './ClearChangesModal';

export default ClearChangesModal;