import ProjectCard from './ProjectCard';

export default ProjectCard;